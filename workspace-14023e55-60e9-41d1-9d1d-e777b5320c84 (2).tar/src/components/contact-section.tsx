import { Mail, Instagram, Globe } from "lucide-react"

export default function ContactSection() {
  return (
    <div className="flex flex-col sm:flex-row gap-8 justify-center items-center text-gray-400 scroll-animate">
      <div className="flex items-center gap-3">
        <Mail className="w-5 h-5 text-red-400" />
        <span>decompe@digitalrevolution.com</span>
      </div>
      <div className="flex items-center gap-3">
        <Instagram className="w-5 h-5 text-red-400" />
        <span>@decompe_revolution</span>
      </div>
      <div className="flex items-center gap-3">
        <Globe className="w-5 h-5 text-red-400" />
        <span>www.decompe4-0.id</span>
      </div>
    </div>
  )
}